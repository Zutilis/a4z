<template>
	<nav class="mobile-menu">
		<div class="menu-header">
			<button class="mobile-header-btn mobile-header-close" @click="handleLinkClick">
				<svg viewBox="0 0 24 23" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M19 5L5 19M5.00001 5L19 19" />
				</svg>
			</button>
			<a href="https://billetterie.a4z.fr/" target="_blank" class="mobile-header-btn mobile-header-ticket">
				<svg viewBox="0 0 32 31" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path
						d="M22.996 11.25h-13.996c-0.414 0-0.75 0.336-0.75 0.75v0 7.605c0 0.414 0.336 0.75 0.75 0.75h13.996c0.414-0 0.75-0.336 0.75-0.75v0-7.605c-0-0.414-0.336-0.75-0.75-0.75v0zM22.246 18.855h-12.496v-6.105h12.496zM30 13.75c0.414-0 0.75-0.336 0.75-0.75v0-5c-0-0.414-0.336-0.75-0.75-0.75h-28c-0.414 0-0.75 0.336-0.75 0.75v0 5c0 0.414 0.336 0.75 0.75 0.75v0c1.243 0 2.25 1.007 2.25 2.25s-1.007 2.25-2.25 2.25v0c-0.414 0-0.75 0.336-0.75 0.75v0 5c0 0.414 0.336 0.75 0.75 0.75h28c0.414-0 0.75-0.336 0.75-0.75v0-5c-0-0.414-0.336-0.75-0.75-0.75v0c-1.243 0-2.25-1.007-2.25-2.25s1.007-2.25 2.25-2.25v0zM29.25 19.674v3.576h-26.5v-3.576c1.724-0.361 3-1.869 3-3.674s-1.276-3.313-2.975-3.67l-0.024-0.004v-3.576h26.5v3.576c-1.724 0.361-3 1.869-3 3.674s1.276 3.313 2.975 3.67l0.024 0.004z" />
				</svg>
			</a>
		</div>

		<ul class="menu-list kensington-xl">
			<li><router-link to="/stands" @click="handleLinkClick">Les stands</router-link></li>
			<li><router-link to="/line-up" @click="handleLinkClick">La line-up</router-link></li>
			<li><router-link to="/food" @click="handleLinkClick">Food</router-link></li>
			<li><router-link to="/partners" @click="handleLinkClick">Partenaires</router-link></li>
		</ul>

		<div class="socials">
			<a href="https://instagram.com/a4z.fr" target="_blank" aria-label="Instagram">
				<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path fill-rule="evenodd" clip-rule="evenodd"
						d="M12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18ZM12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z" />
					<path
						d="M18 5C17.4477 5 17 5.44772 17 6C17 6.55228 17.4477 7 18 7C18.5523 7 19 6.55228 19 6C19 5.44772 18.5523 5 18 5Z" />
					<path fill-rule="evenodd" clip-rule="evenodd"
						d="M1.65396 4.27606C1 5.55953 1 7.23969 1 10.6V13.4C1 16.7603 1 18.4405 1.65396 19.7239C2.2292 20.8529 3.14708 21.7708 4.27606 22.346C5.55953 23 7.23969 23 10.6 23H13.4C16.7603 23 18.4405 23 19.7239 22.346C20.8529 21.7708 21.7708 20.8529 22.346 19.7239C23 18.4405 23 16.7603 23 13.4V10.6C23 7.23969 23 5.55953 22.346 4.27606C21.7708 3.14708 20.8529 2.2292 19.7239 1.65396C18.4405 1 16.7603 1 13.4 1H10.6C7.23969 1 5.55953 1 4.27606 1.65396C3.14708 2.2292 2.2292 3.14708 1.65396 4.27606ZM13.4 3H10.6C8.88684 3 7.72225 3.00156 6.82208 3.0751C5.94524 3.14674 5.49684 3.27659 5.18404 3.43597C4.43139 3.81947 3.81947 4.43139 3.43597 5.18404C3.27659 5.49684 3.14674 5.94524 3.0751 6.82208C3.00156 7.72225 3 8.88684 3 10.6V13.4C3 15.1132 3.00156 16.2777 3.0751 17.1779C3.14674 18.0548 3.27659 18.5032 3.43597 18.816C3.81947 19.5686 4.43139 20.1805 5.18404 20.564C5.49684 20.7234 5.94524 20.8533 6.82208 20.9249C7.72225 20.9984 8.88684 21 10.6 21H13.4C15.1132 21 16.2777 20.9984 17.1779 20.9249C18.0548 20.8533 18.5032 20.7234 18.816 20.564C19.5686 20.1805 20.1805 19.5686 20.564 18.816C20.7234 18.5032 20.8533 18.0548 20.9249 17.1779C20.9984 16.2777 21 15.1132 21 13.4V10.6C21 8.88684 20.9984 7.72225 20.9249 6.82208C20.8533 5.94524 20.7234 5.49684 20.564 5.18404C20.1805 4.43139 19.5686 3.81947 18.816 3.43597C18.5032 3.27659 18.0548 3.14674 17.1779 3.0751C16.2777 3.00156 15.1132 3 13.4 3Z" />
				</svg>
			</a>
			<a href="https://www.tiktok.com/@a4z.fr" target="_blank" aria-label="Tiktok">
				<svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path
						d="M16.656 1.029c1.637-0.025 3.262-0.012 4.886-0.025 0.054 2.031 0.878 3.859 2.189 5.213l-0.002-0.002c1.411 1.271 3.247 2.095 5.271 2.235l0.028 0.002v5.036c-1.912-0.048-3.71-0.489-5.331-1.247l0.082 0.034c-0.784-0.377-1.447-0.764-2.077-1.196l0.052 0.034c-0.012 3.649 0.012 7.298-0.025 10.934-0.103 1.853-0.719 3.543-1.707 4.954l0.020-0.031c-1.652 2.366-4.328 3.919-7.371 4.011l-0.014 0c-0.123 0.006-0.268 0.009-0.414 0.009-1.73 0-3.347-0.482-4.725-1.319l0.040 0.023c-2.508-1.509-4.238-4.091-4.558-7.094l-0.004-0.041c-0.025-0.625-0.037-1.25-0.012-1.862 0.49-4.779 4.494-8.476 9.361-8.476 0.547 0 1.083 0.047 1.604 0.136l-0.056-0.008c0.025 1.849-0.050 3.699-0.050 5.548-0.423-0.153-0.911-0.242-1.42-0.242-1.868 0-3.457 1.194-4.045 2.861l-0.009 0.030c-0.133 0.427-0.21 0.918-0.21 1.426 0 0.206 0.013 0.41 0.037 0.61l-0.002-0.024c0.332 2.046 2.086 3.59 4.201 3.59 0.061 0 0.121-0.001 0.181-0.004l-0.009 0c1.463-0.044 2.733-0.831 3.451-1.994l0.010-0.018c0.267-0.372 0.45-0.822 0.511-1.311l0.001-0.014c0.125-2.237 0.075-4.461 0.087-6.698 0.012-5.036-0.012-10.060 0.025-15.083z">
					</path>
				</svg>
			</a>
			<a href="https://snapchat.com/a4z.fr" target="_blank" aria-label="Snapchat">
				<svg viewBox="0 0 192 192" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path
						d="M95.918 22.002c-11.963-.087-24.145 4.54-32.031 13.717-6.995 7.405-9.636 17.901-9.284 27.868-.03 5.119.032 10.237.05 15.355-4.901-1.217-9.873-4.624-15.063-2.937-4.422 1.313-6.267 7.088-3.596 10.791 2.876 3.761 7.346 5.907 11.08 8.71 1.837 1.5 4.313 2.571 5.68 4.499-.001 4.62-2.425 8.897-4.722 12.786-5.597 8.802-14.342 15.531-23.705 20.18-2.39 1.035-4.59 4.144-2.473 6.499 3.862 3.622 9.327 4.778 14.195 6.486 2.047.64 5.078 1.34 4.886 4.084.335 2.923 2.205 6.066 5.492 6.078 7.873.91 16.289.522 23.345 4.741 6.917 4.006 14.037 8.473 22.255 8.96 8.188.767 16.623-.888 23.642-5.255 5.23-2.884 10.328-6.477 16.456-7.061 5.155-1.206 10.702-.151 15.685-2.072 3.193-1.367 2.762-5.244 4.104-7.808 2.532-1.747 5.77-1.948 8.59-3.102 3.687-1.47 8.335-2.599 10.268-6.413 1.148-3.038-2.312-4.698-4.453-5.88-11.38-5.874-21.631-14.921-26.121-27.191-.496-1.936-2.279-4.834.084-6.255 4.953-4.176 11.413-6.575 15.514-11.715 3.103-3.884.941-10.55-4.141-11.322-4.928-.78-9.525 1.893-14.152 3.127-.404-8.53.502-17.232-.776-25.746-2.429-13.808-13.514-25.157-26.813-29.124-4.521-1.401-9.266-2.037-13.996-2Z" />
				</svg>
			</a>
		</div>
	</nav>
</template>

<script setup>
const emit = defineEmits(['close'])

function handleLinkClick() {
	emit('close')
}
</script>

<style scoped>
.mobile-menu {
	position: fixed;
	display: flex;
	flex-direction: column;
	overflow-y: auto;
	background-color: var(--color-navy-blue);
	padding: 0 var(--space-container-mobile);
	height: 100%;
	z-index: 9999;
	top: 0;
	right: 0;
	left: 0;
	bottom: 0;
}

.menu-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	height: var(--h-navbar-header);
}

.mobile-header-btn {
	width: 3.4375rem;
	height: 3.4375rem;
	padding: .85rem;
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
}

.mobile-header-btn.mobile-header-close {
	background: transparent;
	border: 1px solid var(--color-beige);
}

.mobile-header-btn.mobile-header-close svg {
	stroke: var(--color-beige);
	stroke-width: 1;
	stroke-linecap: round;
}

.mobile-header-btn.mobile-header-ticket {
	background: var(--color-beige);
	border: 1px solid var(--color-beige);
}

.mobile-header-btn.mobile-header-ticket svg {
	fill: var(--color-navy-blue);
}

.menu-list {
	display: flex;
	flex-direction: column;
	margin-top: calc(var(--space-navbar-header) - var(--h-navbar-header));
	gap: .5rem;
}

.menu-list a {
	color: var(--color-beige);
	width: fit-content;
}

.socials {
	display: flex;
	flex-wrap: wrap;
	margin-top: 2rem;
	gap: 1rem;
}

.socials a {
	width: 1.5625rem;
	height: 1.5625rem;
}

.socials svg {
	width: 100%;
	height: 100%;
	fill: var(--color-beige);
}
</style>